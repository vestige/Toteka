define(["Ti/_/Evented"], function(Evented) {
	
	return declare("Ti.Media.AudioPlayer", Evented, {
	});

});